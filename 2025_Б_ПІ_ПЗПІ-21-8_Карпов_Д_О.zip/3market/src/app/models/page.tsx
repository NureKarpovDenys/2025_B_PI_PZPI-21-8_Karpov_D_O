"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import TagDropdown from "@/components/TagDropdown";
import { useSession } from "next-auth/react";
import { FiSearch } from "react-icons/fi";

function usePurchasedModelIds() {
  const { data: session } = useSession();
  const [ids, setIds] = useState<number[]>([]);
  useEffect(() => {
    if (!session?.user?.email) return;
    fetch(`/api/purchases?email=${encodeURIComponent(session.user.email)}`)
      .then((res) => res.json())
      .then((models) => setIds(models.map((m: any) => m.id)));
  }, [session?.user?.email]);
  return ids;
}

type Tag = { id: number; name: string };
type Model = {
  id: number;
  title: string;
  description: string;
  price: number;
  thumbnail_url?: string;
  slug: string;
  tags?: Tag[];
  author_email?: string;
};

type CartItem = {
  id: number;
  title: string;
  price: number;
  thumbnail_url?: string;
};

export default function ModelsPage() {
  const { data: session } = useSession();
  const [models, setModels] = useState<Model[]>([]);
  const [q, setQ] = useState("");
  const [allTags, setAllTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);

  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [author, setAuthor] = useState("");
  const [sort, setSort] = useState("created_at_desc");

  const [cart, setCart] = useState<CartItem[]>([]);
  const purchasedIds = usePurchasedModelIds();

  useEffect(() => {
    fetch("/api/tags")
      .then(res => res.json())
      .then(setAllTags);
    setCart(JSON.parse(localStorage.getItem("cart") || "[]"));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.append("q", q);
    if (selectedTags.length) params.append("tags", selectedTags.join(","));
    if (minPrice) params.append("minPrice", minPrice);
    if (maxPrice) params.append("maxPrice", maxPrice);
    if (author) params.append("author", author);
    if (sort) params.append("sort", sort);
    fetch(`/api/models/search?${params}`)
      .then(res => res.json())
      .then(data => setModels(Array.isArray(data) ? data : []))
      .finally(() => setLoading(false));
  }, [q, selectedTags, minPrice, maxPrice, author, sort]);

  const isInCart = (id: number) => cart.some(item => item.id === id);
  const isPurchased = (id: number) => purchasedIds.includes(id);

  const addToCart = (model: Model) => {
    if (!isInCart(model.id)) {
      const newCart = [
        ...cart,
        {
          id: model.id,
          title: model.title,
          price: model.price,
          thumbnail_url: model.thumbnail_url,
        },
      ];
      setCart(newCart);
      localStorage.setItem("cart", JSON.stringify(newCart));
    }
  };

  const removeFromCart = (id: number) => {
    const newCart = cart.filter((item) => item.id !== id);
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-extrabold mb-6 text-center">Всі моделі</h1>
      <div className="flex flex-col md:flex-row md:items-center gap-3 mb-10">
        <div className="flex-1">
          <div className="relative">
            <input
              type="text"
              placeholder="Пошук 3D-моделей за назвою..."
              value={q}
              onChange={e => setQ(e.target.value)}
              className="w-full pl-10 pr-3 h-12 text-base rounded-xl border-2 border-blue-500 bg-gray-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-400 transition placeholder:text-gray-400"
            />
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400 text-xl" />
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <TagDropdown
            tags={allTags}
            selectedTags={selectedTags}
            setSelectedTags={setSelectedTags}
          />
          <input
            type="number"
            placeholder="Мін. ціна"
            value={minPrice}
            min={0}
            onChange={e => setMinPrice(e.target.value)}
            className="px-3 h-12 rounded-xl border-2 border-gray-700 bg-gray-900 text-white w-28 text-base"
          />
          <input
            type="number"
            placeholder="Макс. ціна"
            value={maxPrice}
            min={0}
            onChange={e => setMaxPrice(e.target.value)}
            className="px-3 h-12 rounded-xl border-2 border-gray-700 bg-gray-900 text-white w-28 text-base"
          />
          <input
            type="text"
            placeholder="Автор (email)"
            value={author}
            onChange={e => setAuthor(e.target.value)}
            className="px-3 h-12 rounded-xl border-2 border-gray-700 bg-gray-900 text-white w-40 text-base"
          />
          <select
            value={sort}
            onChange={e => setSort(e.target.value)}
            className="px-3 h-12 rounded-xl border-2 border-gray-700 bg-gray-900 text-white text-base"
          >
            <option value="created_at_desc">Новіші</option>
            <option value="created_at_asc">Старіші</option>
            <option value="price_asc">Ціна ↑</option>
            <option value="price_desc">Ціна ↓</option>
          </select>
        </div>
      </div>

      {loading && <div className="text-center py-10 text-blue-400 text-lg">Завантаження...</div>}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {models.map(model => (
          <div
            key={model.id}
            className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-4 flex flex-col shadow-xl border-2 border-gray-700 hover:scale-[1.03] hover:shadow-blue-700/30 transition"
          >
            <Link href={`/models/${model.slug}`} className="block">
              {model.thumbnail_url && (
                <img
                  src={model.thumbnail_url}
                  alt={model.title}
                  className="mb-2 rounded-lg w-full h-56 object-cover border-2 border-gray-700"
                />
              )}
              <h3 className="text-lg font-bold mb-1">{model.title}</h3>
              <div className="text-blue-400 font-extrabold mb-1">{model.price} ₴</div>
              <div className="text-xs text-gray-400 mb-2">{model.author_email}</div>
              <div className="flex gap-2 mt-2 flex-wrap">
                {(model.tags ?? []).map(tag => (
                  <span
                    key={tag.id}
                    className="bg-blue-700 text-white rounded-full px-3 py-1 text-xs font-semibold"
                  >
                    {tag.name}
                  </span>
                ))}
              </div>
            </Link>
            <div className="mt-4 flex gap-2">
              {isPurchased(model.id) ? (
                <button
                  disabled
                  className="bg-green-600 text-white px-4 py-2 rounded-xl opacity-90 cursor-not-allowed w-full font-bold"
                >
                  Вже куплено
                </button>
              ) : isInCart(model.id) ? (
                <>
                  <button
                    disabled
                    className="bg-gray-500 text-white px-4 py-2 rounded-xl opacity-90 cursor-not-allowed w-full font-bold"
                  >
                    Вже у кошику
                  </button>
                  <button
                    onClick={() => removeFromCart(model.id)}
                    className="ml-2 px-4 py-2 rounded-xl transition bg-transparent hover:bg-red-700 flex items-center justify-center"
                    aria-label="Видалити з кошика"
                    type="button"
                  >
                    <img
                      src="/trash.ico"
                      alt="Видалити"
                      className="w-6 h-6"
                      style={{ display: "block" }}
                    />
                  </button>
                </>
              ) : (
                <button
                  onClick={() => addToCart(model)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-bold transition w-full shadow"
                >
                  Додати в кошик
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      {!loading && models.length === 0 && (
        <div className="text-gray-400 mt-12 text-center text-lg">Нічого не знайдено</div>
      )}
    </div>
  );
}
