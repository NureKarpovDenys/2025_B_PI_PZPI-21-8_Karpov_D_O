"use client";
import { useParams } from "next/navigation";
import { useEffect, useState, Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";
import { useSession } from "next-auth/react";

type Tag = { id: number; name: string };
type Model = {
  id: number;
  title: string;
  description: string;
  price: number;
  thumbnail_url?: string;
  file_url: string;
  tags?: Tag[];
};

type PurchaseModel = { id: number };
type CartItem = { id: number; title: string; price: number; thumbnail_url?: string };

//3D model viewer
function ModelViewer({ fileUrl }: { fileUrl: string }) {
  const { scene } = useGLTF(fileUrl);

  return (
    <div
      style={{
        height: 620,
        width: 820,
        maxWidth: "98vw",
        background: "#e5e7eb",
        borderRadius: "2rem",
        boxShadow: "0 2px 32px 0 rgba(30,41,59,0.15)",
        overflow: "hidden",
        margin: "0 auto",
      }}
      className="mb-8"
    >
      <Canvas camera={{ position: [1.8, 1.5, 3.2], fov: 36 }}>
        <color attach="background" args={["#e5e7eb"]} />
        {}
        <ambientLight intensity={1.1} />
        <directionalLight
          position={[3, 7, 6]}
          intensity={1.1}
          castShadow
          shadow-mapSize-width={1024}
          shadow-mapSize-height={1024}
        />
        <directionalLight position={[-3, 4, -4]} intensity={0.55} />
        <directionalLight position={[-2, 1, 3]} intensity={0.45} />
        {}
        <primitive object={scene} />
        {}
        <OrbitControls
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          target={[0, 0.6, 0]}
        />
      </Canvas>
    </div>
  );
}

export default function ModelPage() {
  const { slug } = useParams();
  const { data: session } = useSession();
  const [model, setModel] = useState<Model | null>(null);
  const [owned, setOwned] = useState<boolean>(false);
  const [inCart, setInCart] = useState<boolean>(false);

  //load model data by slug
  useEffect(() => {
    fetch(`/api/models/${slug}`)
      .then(res => res.json())
      .then((data: Model) => setModel(data));
  }, [slug]);

  //check if model is purchased
  useEffect(() => {
    if (!model || !session?.user?.email) return;
    fetch(`/api/purchases?email=${encodeURIComponent(session.user.email)}`)
      .then(res => res.json())
      .then((models: PurchaseModel[]) => {
        setOwned(models.some((m: PurchaseModel) => m.id === model.id));
      });
  }, [model, session?.user?.email]);

  //check if model is in cart
  useEffect(() => {
    if (!model) return;
    const cart: CartItem[] = JSON.parse(localStorage.getItem("cart") || "[]");
    setInCart(cart.some((item: CartItem) => item.id === model.id));
  }, [model]);

  //add model to cart
  function addToCart(model: Model) {
    const cart: CartItem[] = JSON.parse(localStorage.getItem("cart") || "[]");
    if (!cart.some((item: CartItem) => item.id === model.id)) {
      cart.push({
        id: model.id,
        title: model.title,
        price: model.price,
        thumbnail_url: model.thumbnail_url,
      });
      localStorage.setItem("cart", JSON.stringify(cart));
      setInCart(true);
      alert("Додано в кошик!");
    } else {
      alert("Ця модель вже у кошику");
    }
  }

  if (!model) return <div>Завантаження...</div>;

  return (
    <div className="max-w-4xl mx-auto p-6 flex flex-col items-center">
      {}
      <h1 className="text-3xl font-extrabold mb-4 text-center">{model.title}</h1>
      {}
      {model.file_url ? (
        <Suspense fallback={<div>Завантаження 3D моделі...</div>}>
          <ModelViewer fileUrl={model.file_url} />
        </Suspense>
      ) : model.thumbnail_url ? (
        <img
          src={model.thumbnail_url}
          alt={model.title}
          className="mb-8 rounded-lg w-full h-[620px] object-cover"
        />
      ) : null}
      {}
      <div className="bg-gray-900 w-full rounded-2xl p-7 text-white shadow-lg mb-2">
        {}
        <div className="mb-4">
          <span className="font-semibold text-lg">Опис:</span>{" "}
          <span className="text-gray-300">{model.description || "—"}</span>
        </div>
        {}
        <div className="mb-4">
          <span className="font-semibold text-lg">Ціна:</span>{" "}
          <span className="text-blue-400 text-xl font-bold">{model.price} ₴</span>
        </div>
        {}
        <div className="mb-6">
          <span className="font-semibold text-lg">Теги:</span>{" "}
          {model.tags && model.tags.length > 0 ? (
            <span className="flex flex-wrap gap-2 mt-2">
              {model.tags.map((tag: Tag) => (
                <span
                  key={tag.id}
                  className="bg-blue-700 text-white rounded-full px-3 py-1 text-sm"
                >
                  {tag.name}
                </span>
              ))}
            </span>
          ) : (
            <span className="text-gray-400">немає</span>
          )}
        </div>
        {}
        <div>
          {owned ? (
            <div className="bg-green-600 text-white px-6 py-3 rounded-xl font-semibold inline-block">
              Модель куплено
            </div>
          ) : inCart ? (
            <div className="bg-gray-400 text-white px-6 py-3 rounded-xl font-semibold inline-block">
              Вже у кошику
            </div>
          ) : (
            <button
              onClick={() => addToCart(model)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold transition text-lg"
            >
              Додати в кошик
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
