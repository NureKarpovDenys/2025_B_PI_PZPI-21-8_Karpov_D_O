"use client";
import dynamic from "next/dynamic";
const ThreeBG = dynamic(() => import("@/components/ThreeBG"), { ssr: false });

export default function HomePage() {
  return (
    <div className="relative flex flex-col min-h-[80vh] items-center justify-center pt-16">
      <ThreeBG />
      <div className="w-full max-w-3xl text-center z-10">
        <h1 className="text-5xl font-bold text-white mb-4 drop-shadow-lg">
          3Market — Твій світ 3D-моделей
        </h1>
        <p className="text-xl text-white/80 mb-8">
          Купуй, продавай і переглядай 3D-моделі онлайн. Все просто.
        </p>
        <div className="flex justify-center gap-4 mb-12">
          <a href="/models" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl text-lg font-semibold transition">
            Переглянути моделі
          </a>
          <a href="/upload" className="bg-white hover:bg-gray-200 text-blue-700 px-6 py-3 rounded-xl text-lg font-semibold transition">
            Завантажити свою
          </a>
        </div>
      </div>
      <section className="w-full max-w-2xl bg-black/100 rounded-xl shadow-lg p-8 mt-8 mb-16">
        <h2 className="text-2xl font-bold text-white mb-4">FAQ</h2>
        <div className="space-y-3 text-left">
          <div>
            <h3 className="font-semibold text-white">Як купити 3D-модель?</h3>
            <p className="text-white/80">Зареєструйтеся, додайте обрану модель у кошик та оплатіть — і одразу завантажуйте!</p>
          </div>
          <div>
            <h3 className="font-semibold text-white">Як продати свою модель?</h3>
            <p className="text-white/80">Створіть акаунт, завантажте .glb модель — і вона стане доступною покупцям.</p>
          </div>
          <div>
            <h3 className="font-semibold text-white">Які формати підтримуються?</h3>
            <p className="text-white/80">Платформа підтримує .glb. (Підтримка інших — скоро!)</p>
          </div>
          <div>
          </div>
        </div>
      </section>
    </div>
  );
}
