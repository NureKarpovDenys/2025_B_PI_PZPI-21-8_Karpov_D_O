"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";

export default function usePurchasedModelIds() {
  const { data: session } = useSession();
  const [ids, setIds] = useState<number[]>([]);

  useEffect(() => {
    if (!session?.user?.email) return;
    fetch(`/api/purchases?email=${encodeURIComponent(session.user.email)}`)
      .then((res) => res.json())
      .then((models) => setIds(models.map((m: any) => m.id)));
  }, [session?.user?.email]);

  return ids;
}
