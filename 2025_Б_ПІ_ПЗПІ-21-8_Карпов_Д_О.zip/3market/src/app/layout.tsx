import "./globals.css";
import { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import SessionProviderWrapper from "@/components/SessionProviderWrapper";

export const metadata = {
  title: "3Market",
  description: "Платформа для 3D-моделей",
    icons: {
    icon: "/favicon.ico", 
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-gradient-to-br from-gray-900 to-black text-white font-sans min-h-screen">
        <SessionProviderWrapper>
          <Navbar />
          <main className="max-w-7xl mx-auto px-4 py-6">{children}</main>
        </SessionProviderWrapper>
      </body>
    </html>
  );
}
