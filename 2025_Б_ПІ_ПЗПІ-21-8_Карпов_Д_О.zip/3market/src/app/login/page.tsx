"use client";

import { signIn, signOut, useSession } from "next-auth/react";
import ThreeLoginBackground from "@/components/ThreeLoginBackground";

export default function LoginPage() {
  const { data: session } = useSession();

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <ThreeLoginBackground />
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <div className="backdrop-blur-md bg-white/10 border border-white/30 rounded-2xl p-8 w-[350px] shadow-xl">
          <h2 className="text-white text-2xl font-semibold text-center mb-6">
            Увійти до 3Market
          </h2>

          {}
          {session ? (
            <div className="flex flex-col items-center gap-4">
              <div className="text-white text-center">
                Ви вже увійшли як <b>{session.user?.email}</b>
              </div>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition"
              >
                Вийти
              </button>
            </div>
          ) : (
            <button
              onClick={() => signIn("google", { callbackUrl: "/" })}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition w-full"
            >
              Увійти через Google
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
