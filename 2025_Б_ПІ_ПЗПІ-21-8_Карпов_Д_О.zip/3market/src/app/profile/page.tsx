"use client";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import Link from "next/link";

interface Model {
  id: number;
  title: string;
  description: string;
  file_url: string;
  thumbnail_url?: string;
  created_at?: string;
  price?: number;
  slug?: string;
}

export default function ProfilePage() {
  const { data: session, status } = useSession();
  const [models, setModels] = useState<Model[]>([]);

  useEffect(() => {
    if (status === "authenticated") {
      fetch("/api/models/user")
        .then((res) => res.json())
        .then((data) => setModels(Array.isArray(data) ? data : []));
    }
  }, [status]);

  if (status === "loading") return <div>Завантаження...</div>;
  if (status === "unauthenticated") return <div>Будь ласка, увійдіть для перегляду профілю</div>;
  if (!session) return null;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center gap-6 mb-8">
        {session.user?.image ? (
          <img
            src={session.user.image}
            alt="avatar"
            className="w-20 h-20 rounded-full border"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="w-20 h-20 rounded-full bg-gray-600 flex items-center justify-center text-white text-3xl">
            {session.user?.email?.[0]?.toUpperCase() ?? "U"}
          </span>
        )}
        <div>
          <div className="text-2xl font-bold">{session.user?.name || session.user?.email}</div>
          <div className="text-gray-400">{session.user?.email}</div>
          <div className="mt-2 text-blue-400 font-semibold">
            Завантажено моделей: {models.length}
          </div>
        </div>
      </div>

      <h2 className="text-xl font-semibold mb-4">Ваші моделі</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {models.length === 0 && (
          <div className="col-span-full text-gray-400">Немає завантажених моделей</div>
        )}
        {models.map((model) => (
          <Link
            href={model.slug ? `/models/${model.slug}` : "#"}
            key={model.id}
            className="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition"
          >
            {model.thumbnail_url && (
              <img
                src={model.thumbnail_url}
                alt={model.title}
                className="mb-2 rounded-lg w-full h-40 object-cover"
              />
            )}
            <h3 className="text-lg font-semibold mb-1">{model.title}</h3>
            <div className="text-sm text-gray-300 mb-1">{model.description}</div>
            <div className="text-blue-400 font-semibold">{model.price} ₴</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
