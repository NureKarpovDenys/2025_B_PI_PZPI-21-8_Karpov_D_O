"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

type Model = {
  id: number;
  title: string;
  file_url: string;
  thumbnail_url?: string;
  slug?: string;
};

export default function PurchasesPage() {
  const { data: session } = useSession();
  const [models, setModels] = useState<Model[]>([]);
  const searchParams = useSearchParams();

  //clear cart if success param in URL
  useEffect(() => {
    if (searchParams?.get("success") === "1") {
      localStorage.removeItem("cart");
    }
  }, [searchParams]);

  //fetch user purchases from API
  useEffect(() => {
    if (!session?.user?.email) return;
    fetch(`/api/purchases?email=${encodeURIComponent(session.user.email)}`)
      .then((res) => res.json())
      .then(setModels);
  }, [session?.user?.email]);

  return (
    <div className="max-w-4xl mx-auto p-8">
      <h2 className="text-2xl font-bold mb-6">Мої покупки</h2>
      {!models.length && <p>Покупок ще не було</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {models.map((model) => (
          <div key={model.id} className="bg-gray-900 rounded-xl p-4 flex gap-4 items-center">
            {model.thumbnail_url && (
              <img
                src={model.thumbnail_url}
                alt={model.title}
                className="w-20 h-20 rounded object-cover"
              />
            )}
            <div>
              <h3 className="font-bold text-lg mb-1">{model.title}</h3>
              <div className="flex gap-3 items-center">
                <Link
                  href={`/models/${model.slug ?? model.id}`}
                  className="text-blue-400 hover:underline text-sm"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Переглянути модель
                </Link>
                <Link
                  href={model.file_url}
                  download
                  className="text-green-400 hover:underline text-sm"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Завантажити
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
