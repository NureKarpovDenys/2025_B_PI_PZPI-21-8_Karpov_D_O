import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
});

export async function POST(req: NextRequest) {
  const { cart, userEmail } = await req.json();

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    mode: "payment",
    customer_email: userEmail,
    line_items: cart.map((item: any) => ({
      price_data: {
        currency: "uah",
        product_data: {
          name: item.title,
        },
        unit_amount: item.price * 100,
      },
      quantity: 1,
    })),
    success_url: "http://localhost:3000/purchases",
    cancel_url: "http://localhost:3000/cart",
    metadata: {
      cart: JSON.stringify(cart), // важливо!
    },
  });

  return NextResponse.json({ url: session.url });
}
