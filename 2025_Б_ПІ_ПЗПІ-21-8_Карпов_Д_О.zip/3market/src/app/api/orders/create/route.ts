import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "../../auth/[...nextauth]/route";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.email) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const { cart } = await req.json();

  if (!Array.isArray(cart) || cart.length === 0) {
    return NextResponse.json({ error: "Empty cart" }, { status: 400 });
  }

  // сума
  const totalAmount = cart.reduce((sum: number, item: any) => sum + (item.price * (item.quantity || 1)), 0);

  // order вставка
  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert([
      {
        buyer_id: session.user.email, // email, якщо це id юзера в твоїй схемі — підставляй id
        status: "new",
        total_amount: totalAmount,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
    .select()
    .single();

  if (orderError) {
    return NextResponse.json({ error: orderError.message }, { status: 500 });
  }

  // order_items вставка
  const itemsToInsert = cart.map((item: any) => ({
    order_id: order.id,
    model_id: item.id,
    unit_price: item.price,
    quantity: item.quantity || 1,
  }));

  const { error: itemsError } = await supabase.from("order_items").insert(itemsToInsert);
  if (itemsError) {
    return NextResponse.json({ error: itemsError.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, orderId: order.id });
}
