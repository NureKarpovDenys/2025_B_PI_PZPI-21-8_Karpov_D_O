import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
});

export async function POST(req: NextRequest) {
  const { cart, email } = await req.json();

  if (!Array.isArray(cart) || cart.length === 0) {
    return NextResponse.json({ error: "Кошик порожній" }, { status: 400 });
  }
  if (!email) {
    return NextResponse.json({ error: "Email відсутній" }, { status: 400 });
  }

  const line_items = cart.map((item: any) => ({
    price_data: {
      currency: "uah",
      product_data: {
        name: item.title,
        images: item.thumbnail_url ? [item.thumbnail_url] : [],
      },
      unit_amount: Math.round(item.price * 100),
    },
    quantity: 1,
  }));

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items,
      mode: "payment",
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/purchases?success=1`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/cart?canceled=1`,
      customer_email: email,
      metadata: { cart: JSON.stringify(cart) },
    });

    return NextResponse.json({ url: session.url });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
