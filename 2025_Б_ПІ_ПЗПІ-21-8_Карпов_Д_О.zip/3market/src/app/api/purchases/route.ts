import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const email = searchParams.get("email");
  if (!email) return NextResponse.json([]);

  // join orders -> order_items -> models, витягуємо всі потрібні поля
  const { data, error } = await supabase
    .from("orders")
    .select(
      `
      id,
      order_items (
        model_id,
        models (
          id,
          title,
          file_url,
          thumbnail_url,
          slug
        )
      )
    `
    )
    .eq("buyer_id", email)
    .eq("status", "paid");

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // flatten to array of models
  const models =
    data
      ?.flatMap((order: any) =>
        order.order_items
          ?.filter((item: any) => item.models)
          .map((item: any) => item.models)
      )
      .filter(Boolean) || [];

  return NextResponse.json(models);
}
