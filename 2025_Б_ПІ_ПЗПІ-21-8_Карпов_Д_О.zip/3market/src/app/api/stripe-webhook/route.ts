import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {});
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  const sig = req.headers.get("stripe-signature");
  const rawBody = await req.text();

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      sig!,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
    console.log("=== Stripe webhook event:", event.type, new Date().toISOString());
  } catch (err: any) {
    console.error("Stripe webhook error:", err.message);
    return NextResponse.json({ error: err.message }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    console.log("=== Checkout session:", JSON.stringify(session, null, 2));

    let userEmail = session.customer_email as string | undefined;
    if (!userEmail && (session as any).customer_details?.email) {
      userEmail = (session as any).customer_details.email;
    }

    if (!userEmail) {
      console.error("NO USER EMAIL in Stripe session!");
      return NextResponse.json({ error: "no user email" }, { status: 400 });
    }

    let cart: any[] = [];
    try {
      if (session.metadata?.cart) {
        cart = JSON.parse(session.metadata.cart);
        console.log("=== Cart:", cart);
      } else {
        console.warn("No cart in metadata!");
      }
    } catch (e) {
      cart = [];
      console.error("Failed to parse cart from metadata");
    }

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert([
        {
          buyer_id: userEmail,
          status: "paid",
          total_amount: session.amount_total ? session.amount_total / 100 : 0,
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (orderError) {
      console.error("Order insert error:", orderError.message);
    } else {
      console.log("Order created:", order);
    }

    // створюємо order_items
    if (order && cart.length > 0) {
      await Promise.all(
        cart.map(async (item) => {
          const { error: oiError } = await supabase.from("order_items").insert({
            order_id: order.id,
            model_id: item.id,
            unit_price: item.price,
            quantity: 1,
          });
          if (oiError) {
            console.error("Order_item insert error:", oiError.message);
          }
        })
      );
      console.log("Order items added!");
    } else {
      if (!order) console.warn("No order created, skipping order_items");
      if (!cart.length) console.warn("Cart is empty, no order_items to insert");
    }
  }

  return NextResponse.json({ received: true });
}
