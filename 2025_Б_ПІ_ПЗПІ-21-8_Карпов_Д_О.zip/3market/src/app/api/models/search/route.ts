import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim().toLowerCase() ?? "";
  const tagIds = searchParams.get("tags")
    ? searchParams.get("tags").split(",").map(Number).filter(Boolean)
    : [];

  const minPrice = Number(searchParams.get("minPrice") || 0);
  const maxPrice = Number(searchParams.get("maxPrice") || 0);
  const author = searchParams.get("author")?.trim().toLowerCase() ?? "";
  const sort = searchParams.get("sort") || "created_at_desc";

  let modelIds: number[] | null = null;
  if (tagIds.length) {
    const { data: modelTags } = await supabase
      .from("model_tags")
      .select("model_id, tag_id")
      .in("tag_id", tagIds);

    const counter = new Map<number, number>();
    (modelTags || []).forEach(({ model_id }) => {
      counter.set(model_id, (counter.get(model_id) ?? 0) + 1);
    });
    modelIds = Array.from(counter.entries())
      .filter(([_, count]) => count === tagIds.length)
      .map(([id]) => id);
    if (!modelIds.length) return NextResponse.json([]);
  }

  let query = supabase
    .from("models")
    .select("*, model_tags:model_tags(tag_id, tags:tags(id, name))");

  if (q) query = query.ilike("title", `%${q}%`);
  if (author) query = query.ilike("author_email", `%${author}%`);
  if (minPrice) query = query.gte("price", minPrice);
  if (maxPrice) query = query.lte("price", maxPrice);
  if (modelIds) query = query.in("id", modelIds);

  if (sort === "created_at_desc") query = query.order("created_at", { ascending: false });
  if (sort === "created_at_asc") query = query.order("created_at", { ascending: true });
  if (sort === "price_asc") query = query.order("price", { ascending: true });
  if (sort === "price_desc") query = query.order("price", { ascending: false });

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const formatted = (data ?? []).map((m: any) => ({
    ...m,
    tags: (m.model_tags ?? []).map((mt: any) => mt.tags),
  }));

  return NextResponse.json(formatted);
}
