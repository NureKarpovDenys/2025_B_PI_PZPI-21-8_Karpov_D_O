import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const { slug } = params;

  const { data, error } = await supabase
    .from("models")
    .select("id, title, slug, description, price, file_url, thumbnail_url, model_tags(tag_id, tags(id, name))")
    .eq("slug", slug)
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 404 });
  }

  const model = {
    ...data,
    tags: data.model_tags?.map((mt: any) => mt.tags),
  };

  return NextResponse.json(model);
}
