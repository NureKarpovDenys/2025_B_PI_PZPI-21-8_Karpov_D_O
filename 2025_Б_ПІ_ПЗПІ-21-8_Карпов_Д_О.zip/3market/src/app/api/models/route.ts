import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { randomUUID } from "crypto";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function GET() {
  const { data, error } = await supabase
    .from("models")
    .select("id, title, slug, description, price, thumbnail_url, model_tags(tag_id, tags(id, name))")
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  //нормалізуємо
  const normalized = data.map((model) => ({
    ...model,
    tags: model.model_tags?.map((mt: any) => mt.tags),
  }));

  return NextResponse.json(normalized);
}


export async function POST(req: NextRequest) {
  const formData = await req.formData();

  const file = formData.get("file") as File | null;
  const thumbnail = formData.get("thumbnail") as File | null;
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const price = Number(formData.get("price"));
  const authorEmail = formData.get("authorEmail") as string;

  if (!file || !thumbnail || !title || !authorEmail || isNaN(price)) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  const modelExt = file.name.split(".").pop();
  const modelFilename = `${randomUUID()}.${modelExt}`;
  const modelBuffer = new Uint8Array(await file.arrayBuffer());

  const { error: uploadModelError } = await supabase.storage
    .from("models")
    .upload(modelFilename, modelBuffer, {
      cacheControl: "3600",
      contentType: file.type || "application/octet-stream",
    });

  if (uploadModelError) {
    return NextResponse.json({ error: uploadModelError.message }, { status: 500 });
  }

  const modelUrl = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/models/${modelFilename}`;

  const thumbExt = thumbnail.name.split(".").pop();
  const thumbFilename = `${randomUUID()}.${thumbExt}`;
  const thumbBuffer = new Uint8Array(await thumbnail.arrayBuffer());

  const { error: uploadThumbError } = await supabase.storage
    .from("thumbnails")
    .upload(thumbFilename, thumbBuffer, {
      cacheControl: "3600",
      contentType: thumbnail.type || "image/jpeg",
    });

  if (uploadThumbError) {
    return NextResponse.json({ error: uploadThumbError.message }, { status: 500 });
  }

  const thumbnailUrl = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/thumbnails/${thumbFilename}`;

  const { data: model, error: insertError } = await supabase
    .from("models")
    .insert([
      {
        title,
        description,
        price,
        file_url: modelUrl,
        thumbnail_url: thumbnailUrl,
        author_email: authorEmail,
        created_at: new Date().toISOString(),
        slug: title.toLowerCase().replace(/\s+/g, "-") + "-" + randomUUID().slice(0, 8),
      },
    ])
    .select()
    .single();

  if (insertError) {
    return NextResponse.json({ error: insertError.message }, { status: 500 });
  }

  const tagIds = formData.getAll("tags[]").map(Number);
  if (model && model.id && tagIds.length > 0) {
    await Promise.all(
      tagIds.map((tagId) =>
        supabase.from("model_tags").insert({ model_id: model.id, tag_id: tagId })
      )
    );
  }

  return NextResponse.json({ success: true, fileUrl: modelUrl }, { status: 200 });
}
