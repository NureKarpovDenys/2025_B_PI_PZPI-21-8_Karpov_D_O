"use client";
import { useSession } from "next-auth/react";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Tag = { id: number; name: string };

export default function UploadModelPage() {
  const { data: session, status } = useSession();
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<Tag[]>([]);
  const [newTag, setNewTag] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const fileRef = useRef<HTMLInputElement>(null);
  const thumbnailRef = useRef<HTMLInputElement>(null);

  //load all tags from API
  useEffect(() => {
    fetch("/api/tags")
      .then((res) => res.json())
      .then(setTags);
  }, []);

  //add tag to selected
  const addTag = (tag: Tag) => {
    if (selectedTags.some((t) => t.id === tag.id)) return;
    setSelectedTags([...selectedTags, tag]);
  };

  //remove tag from selected
  const removeTag = (tagId: number) => {
    setSelectedTags(selectedTags.filter((t) => t.id !== tagId));
  };

  //create and add new tag
  const handleNewTag = async () => {
    const trimmed = newTag.trim();
    if (!trimmed) return;
    if (tags.some((t) => t.name.toLowerCase() === trimmed.toLowerCase())) {
      alert("Такий тег вже існує");
      return;
    }

    const res = await fetch("/api/tags", {
      method: "POST",
      body: JSON.stringify({ name: trimmed }),
      headers: { "Content-Type": "application/json" },
    });

    if (res.ok) {
      const tag = await res.json();
      setTags([...tags, tag]);
      addTag(tag);
      setNewTag("");
    } else {
      alert("Помилка створення тегу");
    }
  };

  //handle upload form submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (!session?.user?.email) {
      alert("Потрібно увійти в акаунт!");
      setLoading(false);
      return;
    }

    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    selectedTags.forEach((tag) => formData.append("tags[]", String(tag.id)));

    const res = await fetch("/api/models/upload", {
      method: "POST",
      body: formData,
      credentials: "include",
    });

    setLoading(false);
    if (res.ok) {
      alert("Успішно завантажено!");
      form.reset();
      setSelectedTags([]);
      if (fileRef.current) fileRef.current.value = "";
      if (thumbnailRef.current) thumbnailRef.current.value = "";
      router.push("/models");
    } else {
      const err = await res.json();
      alert("Помилка: " + err.error);
    }
  };

  //show available tags not selected
  const availableTags = tags.filter(
    (tag) => !selectedTags.some((sel) => sel.id === tag.id)
  );

  if (status === "loading") return <div>Завантаження...</div>;
  //show login block if not authenticated
  if (status === "unauthenticated") {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh]">
        <div className="bg-gray-900/80 border border-blue-600 rounded-2xl shadow-2xl px-8 py-12 text-center max-w-lg mx-auto">
          <div className="flex justify-center mb-4">
            <span className="text-5xl">🔒</span>
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">
            Завантаження доступне лише після входу
          </h2>
          <p className="text-white/80 mb-6">
            Увійдіть у свій акаунт або зареєструйтесь, щоб додавати власні 3D-моделі.
          </p>
          <a
            href="/login"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition"
          >
            Увійти
          </a>
        </div>
      </div>
    );
  }

  //main upload form
  return (
    <div className="flex flex-col items-center min-h-screen bg-gradient-to-br from-gray-900 to-black pt-14">
      <div className="w-full max-w-xl bg-[#10121c]/95 rounded-2xl p-10 shadow-2xl border border-white/10">
        <h2 className="text-3xl font-extrabold mb-8 text-white text-center">
          Завантажити 3D-модель
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6" encType="multipart/form-data">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-white font-medium mb-1" htmlFor="title">
                Назва моделі
              </label>
              <input
                id="title"
                name="title"
                placeholder="Введіть назву"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-1" htmlFor="price">
                Ціна (₴)
              </label>
              <input
                id="price"
                name="price"
                type="number"
                min={0}
                placeholder="0"
                required
                className="input"
              />
            </div>
          </div>
          <div>
            <label className="block text-white font-medium mb-1" htmlFor="description">
              Опис
            </label>
            <textarea
              id="description"
              name="description"
              placeholder="Коротко про модель"
              required
              className="input min-h-[70px] w-123 resize-y"
            />
          </div>
          <div>
            <label className="block text-white font-medium mb-1" htmlFor="file">
              Файл моделі (.glb)
            </label>
            <input
              id="file"
              type="file"
              name="file"
              required
              ref={fileRef}
              accept=".glb"
              className="input file:py-1 file:bg-blue-700 file:text-white file:rounded-lg file:border-0"
            />
          </div>
          <div>
            <label className="block text-white font-medium mb-1" htmlFor="thumbnail">
              Зображення-прев'ю (.jpg/.png)
            </label>
            <input
              id="thumbnail"
              type="file"
              name="thumbnail"
              required
              ref={thumbnailRef}
              accept=".jpg,.jpeg,.png"
              className="input file:py-1 file:bg-blue-700 file:text-white file:rounded-lg file:border-0"
            />
          </div>
          <div>
            <label className="block text-white font-medium mb-1">
              Теги
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {selectedTags.map((tag) => (
                <span
                  key={tag.id}
                  className="bg-blue-700 text-white rounded-full px-3 py-1 flex items-center text-sm"
                >
                  {tag.name}
                  <button
                    type="button"
                    className="ml-2 text-white/70 hover:text-red-400 text-lg"
                    onClick={() => removeTag(tag.id)}
                    aria-label="Видалити тег"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2 my-2">
              <input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Новий тег"
                className="input flex-1"
              />
              <button
                type="button"
                onClick={handleNewTag}
                className="bg-green-600 hover:bg-green-700 text-white rounded px-5 py-1 font-semibold transition"
              >
                Додати
              </button>
            </div>
            {availableTags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-1">
                {availableTags.map((tag) => (
                  <button
                    type="button"
                    key={tag.id}
                    onClick={() => addTag(tag)}
                    className="bg-gray-800 hover:bg-blue-600 text-white rounded-full px-3 py-1 text-sm border border-white/10 transition"
                  >
                    {tag.name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl text-lg transition disabled:opacity-60 disabled:cursor-not-allowed mt-3"
          >
            {loading ? "Завантаження..." : "Завантажити"}
          </button>
        </form>
      </div>
      <style jsx>{`
        .input {
          @apply bg-white/10 text-white rounded-lg px-4 py-2 outline-none border border-white/20 placeholder-white/50 w-full focus:border-blue-400 transition;
        }
      `}</style>
    </div>
  );
}
