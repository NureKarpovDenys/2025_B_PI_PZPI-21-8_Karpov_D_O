"use client";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type CartItem = {
  id: number;
  title: string;
  price: number;
  thumbnail_url?: string;
};

export default function CartPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [cart, setCart] = useState<CartItem[]>([]);

  //load cart from localStorage
  useEffect(() => {
    setCart(JSON.parse(localStorage.getItem("cart") || "[]"));
  }, []);

  //remove item from cart and update localStorage
  const removeFromCart = (id: number) => {
    const newCart = cart.filter((item) => item.id !== id);
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  //calculate total price
  const total = cart.reduce((sum, item) => sum + (item.price || 0), 0);

  //handle checkout via /api/checkout
  const handleCheckout = async () => {
    if (!session?.user?.email) {
      alert("Потрібно увійти в акаунт!");
      return;
    }
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        cart,
        email: session.user.email,
      }),
    });
    const data = await res.json();
    if (data.url) {
      window.location.href = data.url;
    } else {
      alert("Помилка: " + data.error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto mt-12 px-4">
      <h2 className="text-3xl font-bold mb-8 text-white">Кошик</h2>
      {!cart.length ? (
        <div className="text-lg text-gray-300">Кошик порожній</div>
      ) : (
        <>
          <div className="space-y-5 mb-10">
            {cart.map((item) => (
              <div
                key={item.id}
                className="flex items-center bg-gray-700 rounded-xl px-6 py-6 shadow-md"
              >
                {}
                <img
                  src={item.thumbnail_url}
                  alt=""
                  className="w-20 h-20 rounded object-cover mr-6"
                  style={{ minWidth: 80, minHeight: 80 }}
                />
                <div className="flex-1">
                  {}
                  <div className="font-bold text-xl text-white">{item.title}</div>
                  <div className="text-blue-400 text-lg">{item.price} ₴</div>
                </div>
                {}
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="ml-6 text-red-400 font-semibold hover:underline text-lg"
                >
                  Видалити
                </button>
              </div>
            ))}
          </div>
          {}
          <div className="text-2xl font-bold text-white mb-6 flex items-center">
            Сума:&nbsp; <span className="text-blue-400">{total} ₴</span>
          </div>
          {}
          <button
            className="w-full bg-green-600 hover:bg-green-700 text-white text-xl py-4 rounded-lg font-semibold transition"
            onClick={handleCheckout}
          >
            Оплатити
          </button>
        </>
      )}
    </div>
  );
}
