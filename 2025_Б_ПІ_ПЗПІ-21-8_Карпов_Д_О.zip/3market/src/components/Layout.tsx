import "./globals.css";
import { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import { SessionProvider } from "next-auth/react";

export const metadata = {
  title: "3Market",
  description: "Платформа для 3D-моделей",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="uk">
      <body className="bg-gradient-to-br from-gray-900 to-black text-white font-sans min-h-screen">
        <SessionProvider>
          <Navbar />
          <main className="max-w-7xl mx-auto px-4 py-6">{children}</main>
        </SessionProvider>
      </body>
    </html>
  );
}
