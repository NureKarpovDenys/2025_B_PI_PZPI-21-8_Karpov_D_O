"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useState, useRef, useEffect } from "react";
import Image from "next/image";

export default function Navbar() {
  const { data: session } = useSession();
  const [dropdown, setDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdown(false);
      }
    };
    if (dropdown) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdown]);

  return (
    <nav className="bg-gray-900 px-6 py-4 flex justify-between items-center shadow-md">
      <Link href="/" className="flex items-center">
        <Image
          src="/logo.png"
          alt="3Market logo"
          width={48}
          height={48}
          priority
          className="w-12 h-12"
        />
      </Link>
      <div className="flex space-x-6 text-white text-lg items-center">
        {/* "Головна" видалено */}
        <Link href="/models">Моделі</Link>
        <Link href="/cart">Кошик</Link>
        {session?.user && (
          <Link href="/upload">Додати модель</Link>
        )}
        {session?.user && (
          <Link href="/purchases">Мої покупки</Link>
        )}

        {!session ? (
          <Link
            href="/login"
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition"
          >
            Увійти
          </Link>
        ) : (
          <div className="relative" ref={dropdownRef}>
            <button
              className="flex items-center space-x-2 focus:outline-none"
              onClick={() => setDropdown((d) => !d)}
            >
              {session.user?.image ? (
                <img
                  src={session.user.image}
                  alt="avatar"
                  className="w-9 h-9 rounded-full border"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="w-9 h-9 rounded-full bg-gray-600 flex items-center justify-center text-white text-lg">
                  {session.user?.email?.[0]?.toUpperCase() ?? "U"}
                </span>
              )}
              <span className="ml-1">{session.user?.name || session.user?.email}</span>
            </button>
            {dropdown && (
              <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-lg shadow-lg z-30">
                <Link
                  href="/profile"
                  className="block px-4 py-2 text-white hover:bg-gray-700 rounded-t-lg"
                  onClick={() => setDropdown(false)}
                >
                  Переглянути профіль
                </Link>
                <button
                  onClick={() => {
                    setDropdown(false);
                    signOut();
                  }}
                  className="block w-full text-left px-4 py-2 text-white hover:bg-gray-700 rounded-b-lg"
                >
                  Вийти
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
