"use client";
import { useSession } from "next-auth/react";

export default function BuyButton({ cart }: { cart: any[] }) {
  const { data: session } = useSession();

  const handleBuy = async () => {
    if (!session?.user?.email) {
      alert("Потрібно увійти в акаунт!");
      return;
    }
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        cart,
        email: session.user.email,
      }),
    });
    const data = await res.json();
    if (data.url) {
      window.location.href = data.url;
    } else {
      alert("Помилка: " + data.error);
    }
  };

  return (
    <button
      onClick={handleBuy}
      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold"
    >
      Купити
    </button>
  );
}
