"use client";
import { useEffect, useRef, useState } from "react";

type Tag = { id: number; name: string };

export default function TagDropdown({
  tags,
  selectedTags,
  setSelectedTags,
}: {
  tags: Tag[];
  selectedTags: number[];
  setSelectedTags: (ids: number[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    if (open) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const filtered = tags.filter(t =>
    t.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="relative" ref={ref}>
      <button
        className="px-4 py-2 rounded border bg-gray-900 text-white"
        onClick={() => setOpen(o => !o)}
        type="button"
      >
        {selectedTags.length
          ? `Теги: ${selectedTags.length}`
          : "Теги"}
      </button>
      {open && (
        <div className="absolute mt-2 z-40 bg-gray-800 w-72 rounded shadow-lg p-3">
          <input
            placeholder="Пошук тегу..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full mb-2 px-2 py-1 rounded bg-gray-700 text-white"
          />
          <div className="max-h-48 overflow-y-auto">
            {filtered.map(tag => (
              <label
                key={tag.id}
                className="flex items-center gap-2 py-1 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedTags.includes(tag.id)}
                  onChange={() =>
                    setSelectedTags(
                      selectedTags.includes(tag.id)
                        ? selectedTags.filter(id => id !== tag.id)
                        : [...selectedTags, tag.id]
                    )
                  }
                />
                <span>{tag.name}</span>
              </label>
            ))}
            {filtered.length === 0 && (
              <div className="text-gray-400 text-sm">Нічого не знайдено</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
