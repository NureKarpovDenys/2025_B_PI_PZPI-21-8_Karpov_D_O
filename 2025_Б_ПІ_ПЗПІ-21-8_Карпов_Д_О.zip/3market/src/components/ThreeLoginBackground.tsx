import { useEffect, useRef } from "react";
import * as THREE from "three";

const ThreeLoginBackground = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#080b12");

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 8;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    mount.appendChild(renderer.domElement);

    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    const point = new THREE.PointLight(0xffffff, 0.8);
    point.position.set(0, 5, 5);
    const hemisphere = new THREE.HemisphereLight(0xffffff, 0x111122, 0.6);
    scene.add(ambient, point, hemisphere);

    const geometry = new THREE.SphereGeometry(0.7, 32, 32);
    const spheres: THREE.Mesh[] = [];
    const speedsX: number[] = [];
    const baseY: number[] = [];
    const phases: number[] = [];
    const amplitudes: number[] = [];

    const createSphere = () => {
      const hue = Math.floor(Math.random() * 360);
      const material = new THREE.MeshStandardMaterial({
        color: new THREE.Color(`hsl(${hue}, 100%, 25%)`),
        emissive: new THREE.Color(`hsl(${hue}, 100%, 15%)`),
        emissiveIntensity: 0.6,
        roughness: 0.15,
        metalness: 0.4,
      });

      const sphere = new THREE.Mesh(geometry, material);

      const posX = -20;
      const posY = (Math.random() - 0.5) * 8;
      const posZ = (Math.random() - 0.5) * 6;
      const speedX = 0.02 + Math.random() * 0.015; 

      sphere.position.set(posX, posY, posZ);
      scene.add(sphere);
      spheres.push(sphere);
      speedsX.push(speedX);
      baseY.push(posY);
      phases.push(Math.random() * Math.PI * 2);
      amplitudes.push(0.3 + Math.random() * 0.3);
    };

    let initialCount = 0;
    const maxCount = 50;

    const interval = setInterval(() => {
      if (initialCount >= maxCount) {
        clearInterval(interval);
      } else {
        createSphere();
        initialCount++;
      }
    }, 120); 

    const clock = new THREE.Clock();

    const animate = () => {
      requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      spheres.forEach((sphere, i) => {
        sphere.rotation.x += 0.006;
        sphere.rotation.y += 0.006;
        sphere.position.x += speedsX[i];
        sphere.position.y = baseY[i] + Math.sin(elapsed + phases[i]) * amplitudes[i];

        if (sphere.position.x > 16) {
          scene.remove(sphere);
          spheres.splice(i, 1);
          speedsX.splice(i, 1);
          baseY.splice(i, 1);
          phases.splice(i, 1);
          amplitudes.splice(i, 1);
          createSphere();
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      mount.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mountRef} className="fixed inset-0 z-[-1]" />;

};

export default ThreeLoginBackground;
