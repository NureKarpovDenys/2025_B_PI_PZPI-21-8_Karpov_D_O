import {
  pgTable,
  varchar,
  text,
  integer,
  timestamp,
  serial,
  primaryKey,
  unique,
  foreignKey
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: varchar("id", { length: 255 }).primaryKey(), 
  email: varchar("email", { length: 255 }).notNull().unique(),
  role: varchar("role", { length: 50 }).notNull().default("user"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// MODELS: 3D моделі
export const models = pgTable("models", {
  id: serial("id").primaryKey(),
  author_id: varchar("author_id", { length: 255 })
    .notNull()
    .references(() => users.id),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  price: integer("price").notNull(),
  file_url: text("file_url").notNull(),
  thumbnail_url: text("thumbnail_url"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  metadata: text("metadata"), 
});

// TAGS: теги моделей
export const tags = pgTable("tags", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull().unique(),
});

// MODEL_TAGS: звʼязуюча таблиця для моделей і тегів (many-to-many)
export const modelTags = pgTable(
  "model_tags",
  {
    model_id: integer("model_id")
      .notNull()
      .references(() => models.id),
    tag_id: integer("tag_id")
      .notNull()
      .references(() => tags.id),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.model_id, table.tag_id] }),
  })
);

// ORDERS: замовлення користувачів
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  buyer_id: varchar("buyer_id", { length: 255 })
    .notNull()
    .references(() => users.id),
  status: varchar("status", { length: 30 }).notNull().default("pending"),
  total_amount: integer("total_amount").notNull(),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ORDER_ITEMS: позиції у замовленні
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  order_id: integer("order_id")
    .notNull()
    .references(() => orders.id),
  model_id: integer("model_id")
    .notNull()
    .references(() => models.id),
  unit_price: integer("unit_price").notNull(),
  quantity: integer("quantity").notNull().default(1),
});
