CREATE TABLE "models" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(255) NOT NULL,
	"description" text,
	"price" integer NOT NULL,
	"file_url" text NOT NULL,
	"category" varchar(100),
	"created_at" timestamp DEFAULT now(),
	"author_email" varchar(255) NOT NULL
);
--> statement-breakpoint
DROP TABLE "users" CASCADE;